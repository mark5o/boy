import tkinter  as ttk
from tkinter import font 
reg_app=ttk.Tk()
reg_app.title('Register Yourself')
reg_app.geometry('600x400')
font_=font.Font(size=20)

reg_app.mainloop()





# print('Register using another module')