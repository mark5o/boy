import tkinter  as ttk
from tkinter import font
clear_app=ttk.Tk()
clear_app.title('Login')
clear_app.geometry('600x400')
font_=font.Font(size=20)

clear_app.mainloop() 